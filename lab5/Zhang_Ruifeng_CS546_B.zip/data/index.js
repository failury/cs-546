const peopleData = require('./peopledata');
const stocksData = require('./stocksdata');

module.exports = {
  stocks: stocksData,
  people: peopleData
};