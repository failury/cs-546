const res = require('./restaurants');
const rev = require('./reviews');

module.exports = {
  res: res,
  rev: rev
};